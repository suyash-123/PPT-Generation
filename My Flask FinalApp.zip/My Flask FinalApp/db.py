import mysql.connector

class DB:
    def __init__(self):
        self.mydb = mysql.connector.connect(
        user='root', 
        password='Suyash@12345#',
        host='localhost',database='user_info')

    def insert(self,**kwargs):
        myc = self.mydb.cursor()
        sql = "Insert Into user_info(uname,udesignation,usummary,ukp,uad,uaoe) Values(%s,%s,%s,%s,%s,%s)"
        val = (kwargs['uname'],kwargs['udesignation'],kwargs['usummary'],kwargs['ukp'],kwargs['uad'],kwargs['uaoe'])
        myc.execute(sql,val)
        self.mydb.commit()
        rid = myc.lastrowid
        myc.close()
        return rid

    def fetch(self,fid):
        myc = self.mydb.cursor()
        sql = "Select * from user_info where uid=%s"
        val = (fid,)
        myc.execute(sql,val)
        myf = myc.fetchone()
        myc.close()
        return myf