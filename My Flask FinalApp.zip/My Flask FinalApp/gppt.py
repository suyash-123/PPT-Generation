from pptx import Presentation
from pptx.util import Inches
from collections import namedtuple
from pptx.dml.color import RGBColor
import os

#current cwd
cwd = os.getcwd()
ppt_path = os.path.join(cwd,'gen_ppt')


Color = namedtuple('RGB','red, green, blue')
class RGB(Color):
    def hex_format(self):
        return '#{:02X}{:02X}{:02X}'.format(self.red,self.green,self.blue)



def gppt(file_data):
    #Creating ppt
    prs = Presentation()


    title_only_slide_layout = prs.slide_layouts[5]
    slide = prs.slides.add_slide(title_only_slide_layout)
    shapes = slide.shapes

    # shapes.title.text = 'User Profile Automation'

    rows = 8
    cols = 2
    left = top = right = Inches(0.2)
    width = Inches(6.0)
    height = Inches(6.0)
    table = shapes.add_table(rows, cols, left, top, width, height).table

    # set column widths
    table.columns[0].width = Inches(4.5)
    table.columns[1].width = Inches(5.0)

    # write column headings

    table.cell(0, 0).text = file_data['uname']
    table.cell(0,1).text = file_data['udesignation']

    # write body cells

    table.cell(1, 0).text = 'Summary'
    table.cell(2,0).text= str(file_data['usummary']).replace("\r","")
    table.cell(1,1).text = 'Key Projects'
    table.cell(2,1).text = str(file_data['ukp']).replace("\r","")
    table.cell(3,0).text= 'Academic Details'
    table.cell(4, 0).text = str(file_data['uad']).replace("\r","")
    table.cell(5,0).text = 'Area of Expertise'
    table.cell(6, 0).text = file_data['uaoe'].replace("\r","")



    # merging cell_1

    cell_1 = table.cell(0, 0)
    other_cell_1 = table.cell(0, 1)
    cell_1.merge(other_cell_1)

    # merging cell_2

    # cell_2 = table.cell(0, 0)
    # other_cell_2 = table.cell(0, 1)
    # cell_2.merge(other_cell_2)

    # # merging cell_3

    cell_3 = table.cell(6, 0)
    other_cell_3 = table.cell(7, 0)
    cell_3.merge(other_cell_3)
    #
    #
    #
    # # merging cell_4
    #
    # cell_4 = table.cell(10, 0)
    # other_cell_4 = table.cell(11, 0)
    # cell_4.is_merge_origin
    # cell_4.merge(other_cell_4)
    # cell_4.is_merge_origin
    #
    #
    #  # merging cell_5

    cell_5 = table.cell(2, 1)
    other_cell_5 = table.cell(7, 1)

    cell_5.is_merge_origin
    cell_5.merge(other_cell_5)
    cell_5.is_merge_origin

    cell = table.cell(1, 0)
    fill = cell.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(156,102,31)

    cell = table.cell(1, 1)
    fill = cell.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(210,105,30)

    cell = table.cell(3, 0)
    fill = cell.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(0,205,205)

    cell = table.cell(5, 0)
    fill = cell.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(0,139,139)

    cell = table.cell(0, 0)
    fill = cell.fill
    fill.solid()
    fill.fore_color.rgb = RGBColor(238,173,14)


    fn = ppt_path + '/' + f"{file_data['uname']}" + '.pptx'

    prs.save(fn)
