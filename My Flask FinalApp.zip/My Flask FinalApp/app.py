from flask import Flask,request
from flask import Flask,jsonify,request
from db import DB
from gppt import gppt

app = Flask(__name__)
mydb = DB()

@app.route('/createppt',methods=['POST','GET'])
def createPPT():
    if request.method == "POST":
        user = request.json
        uname = user['uname']
        udesignation = user['udesignation']
        usummary = user['usummary']
        ukp = user['ukp']
        uad = user['uad']
        uaoe = user['uaoe']

        # Generating PPT
        gppt({'uname':uname,'udesignation':udesignation,'usummary':usummary,'ukp':ukp,'uad':uad,'uaoe':uaoe})
        # inserting data into DB
        fid = mydb.insert(uname=uname,udesignation=udesignation,usummary=usummary,ukp=ukp,uad=uad,uaoe=uaoe)
        return jsonify({'File ID':fid,'Message':'PPT Created Successfully'})
    return jsonify(res='Showing Form')

@app.route('/getFile/<int:fid>')
def getFileData(fid):
    myf = mydb.fetch(fid)
    if myf == None:
        return jsonify(res="No File Found")    
    return jsonify(uname=myf[1],udesignation=myf[2],usummary=myf[3],ukp=myf[4],uad=myf[5],uaoe=myf[6])
    

if __name__=='__main__':
    app.run(debug=True)
    mydb.close()